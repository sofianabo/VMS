import 'dart:ui' as ui;
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:printing/printing.dart';
import 'package:vms_school/Link/API/Share_Image.dart' show sendImageToServer;
import 'package:vms_school/view/SMS_Platform/Admin/Students_Manager/Export_Jalaa_Pages/Export_Jalaa.dart';

// المتغير العام للإلغاء
bool cancelOperation = false;

// الدالة الرئيسية للطباعة
Future<void> captureAndPrint() async {
  cancelOperation = false;
  CancelToken cansleToken = CancelToken();

  final ValueNotifier<int> progressNotifier = ValueNotifier<int>(0);

  // فتح الـ Dialog
  Get.dialog(
    PrintingDialog(
      progressNotifier: progressNotifier,
      cansleToken: cansleToken,
    ),
    barrierDismissible: false,
  );

  try {
    await Future.delayed(const Duration(milliseconds: 200));
    if (cancelOperation) return;
    progressNotifier.value = 20;

    final widget = Container(
      padding: const EdgeInsets.only(top: 70.0),
      color: Colors.white,
      child: buildPrintContent(), // هذا تابع يجب أن يرجع Widget للطباعة
    );

    await Future.delayed(const Duration(milliseconds: 100));
    if (cancelOperation) return;
    progressNotifier.value = 40;

    final image = await WidgetWraper.toImage(
      widget,
      logicalSize: const Size(1500, 1300),
      pixelRatio: 3.0,
    );

    await Future.delayed(const Duration(milliseconds: 100));
    if (cancelOperation) return;
    progressNotifier.value = 60;

    final imageBytes = await image.toByteData(format: ui.ImageByteFormat.png);
    if (imageBytes == null || cancelOperation) return;
    progressNotifier.value = 80;

    final pngBytes = imageBytes.buffer.asUint8List();
    final pdfBytes = await sendImageToServer(pngBytes, cansleToken);

    if (pdfBytes == null || cancelOperation) return;
    progressNotifier.value = 100;

    await Printing.layoutPdf(onLayout: (_) async => pdfBytes);
  } catch (e) {
    // يمكن إظهار خطأ هنا إن أردت
  } finally {
    if (Get.isDialogOpen ?? false) {
      Get.back(); // إغلاق الـ Dialog
    }
  }
}

class PrintingDialog extends StatelessWidget {
  final ValueNotifier<int> progressNotifier;
  CancelToken cansleToken = CancelToken();
  PrintingDialog(
      {super.key, required this.progressNotifier, required this.cansleToken});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text("تحميل"),
      content: ValueListenableBuilder<int>(
        valueListenable: progressNotifier,
        builder: (context, progress, _) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              LinearProgressIndicator(value: progress / 100),
              const SizedBox(height: 15),
              Text("يتم تجهيز العناصر... ($progress%)"),
            ],
          );
        },
      ),
      actions: [
        TextButton(
          onPressed: () {
            cancelOperation = true;
            cansleToken.cancel();
            Get.back();
          },
          child: const Text("إلغاء"),
        ),
      ],
    );
  }
}

String convertToArabicNumbers(String input) {
  const english = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  const arabic = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];

  for (int i = 0; i < english.length; i++) {
    input = input.replaceAll(english[i], arabic[i]);
  }
  return input;
}
