import 'package:flutter/material.dart';
import 'package:vms_school/view/SMS_Platform/Admin/Students_Manager/Export_Jalaa_Pages/First_Table/First_Table_Widgets.dart';

class First_Table_Design extends StatelessWidget {
  const First_Table_Design({super.key});

  @override
  Widget build(BuildContext context) {
    return Table(
      defaultVerticalAlignment: TableCellVerticalAlignment.middle,
      columnWidths: {
        0: FixedColumnWidth(160), // المواد الدراسية
        1: FixedColumnWidth(40), // الدرجة العظمى
        2: FixedColumnWidth(300), // الفصل الدراسي الأول
        3: FixedColumnWidth(300), // الفصل الدراسي الثاني
        4: FixedColumnWidth(60), // الدرجة العظمى
        5: FixedColumnWidth(60), // الدرجة العظمى
        6: FixedColumnWidth(200),
      },
      children: [
        // Main Table Header
        TableRow(
          children: [
            buildCell('المواد الدراسية'),
            buildRotateCell('الدرجة العظمى'),
            The_First_Semester_Cell('الفصل الدراسي الأول'),
            The_Second_Semester_Cell('الفصل الدراسي الثاني'),
            Container(
              height: 133,
              decoration: BoxDecoration(
                  border: Border(
                top: BorderSide(color: Colors.black, width: 2),
                left: BorderSide(color: Colors.black, width: 2),
                right: BorderSide(color: Colors.black, width: 2),
              )),
            ),
            buildRotateCell('مجموع درجات\nالفصلين'),
            The_Final_SUM_Semester_Cell('الدرجة النهائية\n((محصلة الفصلين))')
          ],
        ),
        // Normal Table Row
        TableRow(
          children: [
            buildDgree('التربية الدينية',
                isLeft: true, isRight: true, isBold: true),
            buildDgree('200', isLeft: true, isBold: true),
            buildSplitDgree(
              data: [
                {
                  "text": "120",
                  "width": 39,
                },
                {
                  "text": 120,
                  "width": 60,
                },
                {
                  "text": 120,
                  "width": 100,
                },
                {
                  "text": 120,
                  "width": 101,
                }
              ],
            ),
            buildSplitDgree(
              isRight: true,
              data: [
                {
                  "text": 120,
                  "width": 38,
                },
                {
                  "text": 120,
                  "width": 59,
                },
                {
                  "text": 120,
                  "width": 100,
                },
                {
                  "text": 120,
                  "width": 101,
                }
              ],
            ),
            buildDgree(
              isRight: true,
              isLeft: true,
              '',
            ),
            buildDgree(
              isLeft: true,
              'fds',
            ),
            buildSplitDgree(
              data: [
                {
                  "text": 120,
                  "width": 99,
                },
                {
                  "text": 120,
                  "width": 99,
                },
              ],
            ),
          ],
        ),
        // Split Arabic Exam Table Row
        TableRow(
          children: [
            buildTowDgree('اللغة العربية',
                isLeft: true, isRight: true, isBold: true),
            Column(
              children: [
                buildTowDgreeMarks(data: [
                  {
                    "text": 120,
                    "width": 38,
                  },
                ], isLeft: true, isBold: true),
                buildTowDgreeMarks(data: [
                  {
                    "text": 120,
                    "width": 38,
                  },
                ], isLeft: true, isBold: true),
              ],
            ),
            Column(
              children: [
                buildTowDgreeMarks(
                  data: [
                    {
                      "text": 120,
                      "width": 39,
                    },
                    {
                      "text": 120,
                      "width": 60,
                    },
                    {
                      "text": 120,
                      "width": 100,
                    },
                    {
                      "text": 120,
                      "width": 101,
                    }
                  ],
                ),
                buildTowDgreeMarks(
                  data: [
                    {
                      "text": 120,
                      "width": 39,
                    },
                    {
                      "text": 120,
                      "width": 60,
                    },
                    {
                      "text": 120,
                      "width": 100,
                    },
                    {
                      "text": 120,
                      "width": 101,
                    }
                  ],
                ),
              ],
            ),
            Column(
              children: [
                buildTowDgreeMarks(
                  isRight: true,
                  data: [
                    {
                      "text": 120,
                      "width": 38,
                    },
                    {
                      "text": 120,
                      "width": 59,
                    },
                    {
                      "text": 120,
                      "width": 100,
                    },
                    {
                      "text": 120,
                      "width": 101,
                    }
                  ],
                ),
                buildTowDgreeMarks(
                  isRight: true,
                  data: [
                    {
                      "text": 120,
                      "width": 38,
                    },
                    {
                      "text": 120,
                      "width": 59,
                    },
                    {
                      "text": 120,
                      "width": 100,
                    },
                    {
                      "text": 120,
                      "width": 101,
                    }
                  ],
                ),
              ],
            ),
            Column(
              children: [
                buildTowDgreeMarks(
                  data: [],
                  isRight: true,
                  isLeft: true,
                ),
                buildTowDgreeMarks(
                  data: [],
                  isRight: true,
                  isLeft: true,
                ),
              ],
            ),
            Column(
              children: [
                buildTowDgreeMarks(
                  data: [],
                  isLeft: true,
                ),
                buildTowDgreeMarks(
                  data: [],
                  isLeft: true,
                ),
              ],
            ),
            Column(
              children: [
                buildTowDgreeMarksEnd(
                  isLeft: true,
                  data: [
                    {
                      "text": "عربي 1",
                      "width": 99,
                    },
                    {
                      "text": "عربي 1",
                      "width": 99,
                    },
                  ],
                ),
                buildTowDgreeMarksEnd(
                  isLeft: true,
                  data: [
                    {
                      "text": "عربي 2",
                      "width": 99,
                    },
                    {
                      "text": "عربي2",
                      "width": 99,
                    },
                  ],
                ),
              ],
            ),
          ],
        ),
        // Normal Table Row
        TableRow(
          children: [
            buildDgree('التربية الدينية', isLeft: true, isRight: true),
            buildDgree(
              '200',
              isLeft: true,
            ),
            buildSplitDgree(
              data: [
                {
                  "text": "120",
                  "width": 39,
                },
                {
                  "text": 120,
                  "width": 60,
                },
                {
                  "text": 120,
                  "width": 100,
                },
                {
                  "text": 120,
                  "width": 101,
                }
              ],
            ),
            buildSplitDgree(
              isRight: true,
              data: [
                {
                  "text": 120,
                  "width": 38,
                },
                {
                  "text": 120,
                  "width": 59,
                },
                {
                  "text": 120,
                  "width": 100,
                },
                {
                  "text": 120,
                  "width": 101,
                }
              ],
            ),
            buildDgree(
              isRight: true,
              isLeft: true,
              '',
            ),
            buildDgree(
              isLeft: true,
              'fds',
            ),
            buildSplitDgree(
              data: [
                {
                  "text": 120,
                  "width": 99,
                },
                {
                  "text": 120,
                  "width": 99,
                },
              ],
            ),
          ],
        ),
        // Normal Table Row
        TableRow(
          children: [
            buildDgree('التربية الدينية', isLeft: true, isRight: true),
            buildDgree(
              '200',
              isLeft: true,
            ),
            buildSplitDgree(
              data: [
                {
                  "text": "120",
                  "width": 39,
                },
                {
                  "text": 120,
                  "width": 60,
                },
                {
                  "text": 120,
                  "width": 100,
                },
                {
                  "text": 120,
                  "width": 101,
                }
              ],
            ),
            buildSplitDgree(
              isRight: true,
              data: [
                {
                  "text": 120,
                  "width": 38,
                },
                {
                  "text": 120,
                  "width": 59,
                },
                {
                  "text": 120,
                  "width": 100,
                },
                {
                  "text": 120,
                  "width": 101,
                }
              ],
            ),
            buildDgree(
              isRight: true,
              isLeft: true,
              '',
            ),
            buildDgree(
              isLeft: true,
              'fds',
            ),
            buildSplitDgree(
              data: [
                {
                  "text": 120,
                  "width": 99,
                },
                {
                  "text": 120,
                  "width": 99,
                },
              ],
            ),
          ],
        ),
        // Normal Table Row
        TableRow(
          children: [
            buildDgree('التربية الدينية', isLeft: true, isRight: true),
            buildDgree(
              '200',
              isLeft: true,
            ),
            buildSplitDgree(
              data: [
                {
                  "text": "120",
                  "width": 39,
                },
                {
                  "text": 120,
                  "width": 60,
                },
                {
                  "text": 120,
                  "width": 100,
                },
                {
                  "text": 120,
                  "width": 101,
                }
              ],
            ),
            buildSplitDgree(
              isRight: true,
              data: [
                {
                  "text": 120,
                  "width": 38,
                },
                {
                  "text": 120,
                  "width": 59,
                },
                {
                  "text": 120,
                  "width": 100,
                },
                {
                  "text": 120,
                  "width": 101,
                }
              ],
            ),
            buildDgree(
              isRight: true,
              isLeft: true,
              '',
            ),
            buildDgree(
              isLeft: true,
              'fds',
            ),
            buildSplitDgree(
              data: [
                {
                  "text": 120,
                  "width": 99,
                },
                {
                  "text": 120,
                  "width": 99,
                },
              ],
            ),
          ],
        ),
        // Normal Table Row
        TableRow(
          children: [
            buildDgree('التربية الدينية', isLeft: true, isRight: true),
            buildDgree(
              '200',
              isLeft: true,
            ),
            buildSplitDgree(
              data: [
                {
                  "text": "120",
                  "width": 39,
                },
                {
                  "text": 120,
                  "width": 60,
                },
                {
                  "text": 120,
                  "width": 100,
                },
                {
                  "text": 120,
                  "width": 101,
                }
              ],
            ),
            buildSplitDgree(
              isRight: true,
              data: [
                {
                  "text": 120,
                  "width": 38,
                },
                {
                  "text": 120,
                  "width": 59,
                },
                {
                  "text": 120,
                  "width": 100,
                },
                {
                  "text": 120,
                  "width": 101,
                }
              ],
            ),
            buildDgree(
              isRight: true,
              isLeft: true,
              '',
            ),
            buildDgree(
              isLeft: true,
              'fds',
            ),
            buildSplitDgree(
              data: [
                {
                  "text": 120,
                  "width": 99,
                },
                {
                  "text": 120,
                  "width": 99,
                },
              ],
            ),
          ],
        ),
        // The Sum Table Row
        TableRow(
          children: [
            buildDgree('المجموع العام',
                isLeft: true, isRight: true, isBold: true),
            buildDgree('1100', isLeft: true, isBold: true),
            buildSplitDgree(
              data: [
                {
                  "text": 149,
                  "width": 99,
                },
                {
                  "text": 75,
                  "width": 100,
                },
                {
                  "text": 75,
                  "width": 100,
                }
              ],
            ),
            buildSplitDgree(
              isRight: true,
              data: [
                {
                  "text": 149,
                  "width": 97,
                },
                {
                  "text": 75,
                  "width": 100,
                },
                {
                  "text": 75,
                  "width": 100,
                }
              ],
            ),
            buildDgree(
              isRight: true,
              isLeft: true,
              '',
            ),
            buildDgree(
              isLeft: true,
              'fds',
            ),
            buildSplitDgree(
              data: [
                {
                  "text": 120,
                  "width": 99,
                },
                {
                  "text": 120,
                  "width": 99,
                },
              ],
            ),
          ],
        ),
        // The Sum Table Row
        TableRow(
          children: [
            buildDgree('التربية المهنية',
                isLeft: true, isRight: true, isBold: true),
            buildDgree('1100', isLeft: true, isBold: true),
            buildSplitDgree(
              data: [
                {
                  "text": 149,
                  "width": 99,
                },
                {
                  "text": 75,
                  "width": 100,
                },
                {
                  "text": 75,
                  "width": 100,
                }
              ],
            ),
            buildSplitDgree(
              isRight: true,
              data: [
                {
                  "text": 149,
                  "width": 97,
                },
                {
                  "text": 75,
                  "width": 100,
                },
                {
                  "text": 75,
                  "width": 100,
                }
              ],
            ),
            buildDgree(
              isRight: true,
              isLeft: true,
              '',
            ),
            buildDgree(
              isLeft: true,
              'fds',
            ),
            buildSplitDgree(
              data: [
                {
                  "text": 120,
                  "width": 99,
                },
                {
                  "text": 120,
                  "width": 99,
                },
              ],
            ),
          ],
        ),
        // The Sum Table Row
        TableRow(
          children: [
            buildDgree('السلوك', isLeft: true, isRight: true, isBold: true),
            buildDgree(
              isBold: true,
              '1100',
              isLeft: true,
            ),
            buildSplitDgree(
              data: [
                {
                  "text": 149,
                  "width": 99,
                },
                {
                  "text": 75,
                  "width": 100,
                },
                {
                  "text": 75,
                  "width": 100,
                }
              ],
            ),
            buildSplitDgree(
              isRight: true,
              data: [
                {
                  "text": 149,
                  "width": 97,
                },
                {
                  "text": 75,
                  "width": 100,
                },
                {
                  "text": 75,
                  "width": 100,
                }
              ],
            ),
            buildDgree(
              isRight: true,
              isLeft: true,
              '',
            ),
            buildDgree(
              isLeft: true,
              'fds',
            ),
            buildSplitDgree(
              data: [
                {
                  "text": 120,
                  "width": 99,
                },
                {
                  "text": 120,
                  "width": 99,
                },
              ],
            ),
          ],
        ),
        // The Second Sum Table Row
        TableRow(
          children: [
            buildDgree('المجموع النهائي',
                isLeft: true, isRight: true, isBold: true),
            buildDgree('1100', isLeft: true, isBold: true),
            buildSplitDgree(
              data: [
                {
                  "text": 149,
                  "width": 99,
                },
                {
                  "text": 75,
                  "width": 100,
                },
                {
                  "text": 75,
                  "width": 100,
                }
              ],
            ),
            buildSplitDgree(
              isRight: true,
              data: [
                {
                  "text": 149,
                  "width": 97,
                },
                {
                  "text": 75,
                  "width": 100,
                },
                {
                  "text": 75,
                  "width": 100,
                }
              ],
            ),
            buildDgree(
              isRight: true,
              isLeft: true,
              '',
            ),
            buildDgree(
              isLeft: true,
              'fds',
            ),
            buildSplitDgree(
              data: [
                {
                  "text": 120,
                  "width": 99,
                },
                {
                  "text": 120,
                  "width": 99,
                },
              ],
            ),
          ],
        ),
      ],
    );
  }
}
