import 'package:flutter/material.dart';
import 'package:vms_school/view/SMS_Platform/Admin/Students_Manager/Export_Jalaa_Pages/Second_Table/Second_Table_Widgets.dart';

class Second_Table_Design extends StatelessWidget {
  const Second_Table_Design({super.key});

  @override
  Widget build(BuildContext context) {
    return Table(
      defaultVerticalAlignment: TableCellVerticalAlignment.middle,
      columnWidths: {
        0: FixedColumnWidth(80), // الدرجة العظمى
        1: FixedColumnWidth(40), // الدرجة العظمى
        2: FixedColumnWidth(40), // الدرجة العظمى
        3: FixedColumnWidth(80), // الدرجة العظمى
        4: FixedColumnWidth(55), // الدرجة العظمى
      },
      children: [
        TableRow(
          children: [
            buildRotateWithTextCell('الدوام المدرسي', "الفصل الأول",
                isRight: true),
            buildRotateWithTextCell('الدوام الفعلي', "94", isRight: true),
            buildRotateWithTextCell('دوام التلميذ', "94", isRight: true),
            buildRotateGheabCell('الغياب', isRight: true),
            buildRotateWithTextCellWithBottom('النسبة المئوية\nللدوام', "94",
                isLeft: true, isRight: true),
          ],
        ),
        TableRow(
          children: [
            buildDgreeSecondTable('الفصل الثاني', isRight: true),
            buildDgreeSecondTable(isRight: true, '20'),
            buildDgreeSecondTable(isRight: true, '20'),
            buildSplitDgreeSecondTable(
              isRight: true,
              data: [
                {
                  "text": "-",
                  "width": 38,
                },
                {
                  "text": "-",
                  "width": 40,
                },
              ],
            ),
            buildDgreeSecondTable('100', isLeft: true, isRight: true),
          ],
        ),
        TableRow(
          children: [
            buildDgreeSecondTable('المجموع', isRight: true),
            buildDgreeSecondTable(isRight: true, '20'),
            buildDgreeSecondTable(isRight: true, '20'),
            buildSplitDgreeSecondTable(
              isRight: true,
              data: [
                {
                  "text": "-",
                  "width": 38,
                },
                {
                  "text": "-",
                  "width": 40,
                },
              ],
            ),
            buildDgreeSecondTable('100', isLeft: true, isRight: true),
          ],
        ),
      ],
    );
  }
}
